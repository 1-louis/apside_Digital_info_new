﻿namespace Digital_info.Models
{
	public class ConversationViewModel
	{

	}
}
